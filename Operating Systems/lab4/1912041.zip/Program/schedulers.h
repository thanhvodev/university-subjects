#include <stdio.h>
#include "process.h"

void print(Process p[], int n)
{
	int total_waiting_time = 0;
	int total_turnaround_time = 0;
	int total_response_time = 0;
	for (int i = 0; i < n; i++)
	{
		total_waiting_time += p[i].waiting_time;
		total_turnaround_time += p[i].turnaround_time;
		total_response_time += p[i].response_time;
	}
	printf("\tAverage Waiting Time   : %-2.2lf\n", 1.0 * total_waiting_time / n);
	printf("\tAverage Turnaround Time: %-2.2lf\n", 1.0 * total_turnaround_time / n);
	printf("\tAverage Response Time  : %-2.2lf\n\n", 1.0 * total_response_time / n);

	printf("\t| PID | Arrive Time | Burst Time | Priority | Return Time |  Response Time  | Waiting Time | Turnaround Time |\n");
	for (int i = 0; i < n; i++)
	{
		printf("\t| %3s |     %3d     |     %3d    |    %3d   |     %3d     |      %3d        |      %3d     |        %3d      |\n",
			   p[i].id, p[i].arrive_time, p[i].burst, p[i].priority, p[i].return_time, p[i].response_time, p[i].waiting_time, p[i].turnaround_time);
	}
	printf("\n");
}

void FCFS(Process *p, int num_process)
{
	int now = 0, counter = 0;

	while (counter < num_process)
	{
		if (now >= p[counter].arrive_time)
		{
			if (p[counter].executing == false && p[counter].tmp_burst_ > 0)
			{
				// first time executing
				p[counter].response_time = now - p[counter].arrive_time;
				p[counter].waiting_time = now - p[counter].arrive_time;
				p[counter].executing = true;
			}
			else if (p[counter].tmp_burst_ == 0)
			{
				p[counter].return_time = now;
				p[counter].turnaround_time = now - p[counter].arrive_time;
				p[counter].completed = true;
				p[counter].executing = false;

				counter += 1;
				// if finish => change to the next process
				// do not update now before updating p[counter+1].response_time ....
				continue;
			}
			p[counter].tmp_burst_ -= 1;
		}
		now += 1;
	}
}

int findMinBurstTime(Process *p, int num_process)
{
	int minBurstTime = 1000;

	for (int i = 0; i < num_process; i++) //find min burst time
	{
		if (p[i].executing == true && p[i].burst < minBurstTime && p[i].completed == false)
		{
			minBurstTime = p[i].burst;
		}
	}
	return minBurstTime;
}

int indexOfProcessMinBurst(Process *p, int num_process, int minBurstTime)
{
	for (int i = 0; i < num_process; i++)
	{
		if (p[i].executing == true && p[i].burst == minBurstTime && p[i].completed == false)
		{
			return i;
		}
	}
	return -1;
}

void flagProcess(Process *p, int num_process, int now)
{
	for (int i = 0; i < num_process; i++) //make process is ready
	{
		if (now >= p[i].arrive_time && p[i].completed == false && p[i].executing == false)
		{
			p[i].executing = true;
		}
	}
}

int getMaxPriorityInExecutingProcess(Process *p, int num_process)
{
	int maxPri = -1;

	for (int i = 0; i < num_process; i++) //find min burst time
	{
		if (p[i].executing == true && p[i].priority > maxPri && p[i].completed == false)
		{
			maxPri = p[i].priority;
		}
	}
	return maxPri;
}

void SJF(Process *p, int num_process) //non-preemptive
{
	// To do -----------------------------
	int now = 0, counter = 0, index;

	while (counter < num_process)
	{
		if (now >= p[0].arrive_time && p[0].tmp_burst_ > 0)
		{
			p[0].executing = true;
			p[0].response_time = 0;
			p[0].waiting_time = 0;
			p[0].return_time = p[0].burst;
			p[0].turnaround_time = p[0].burst;
			p[0].tmp_burst_ -= 1;
			flagProcess(p, num_process, now);
		}
		else if (p[0].tmp_burst_ == 0 && p[0].executing == true)
		{
			counter += 1;
			p[0].executing = false;
			p[0].completed = true;
			int min = findMinBurstTime(p, num_process);
			index = indexOfProcessMinBurst(p, num_process, min);
			p[index].response_time = now - p[index].arrive_time;
			p[index].waiting_time = now - p[index].arrive_time;
			p[index].return_time = now + p[index].burst;
			p[index].turnaround_time = p[index].return_time - p[index].arrive_time;
		}
		if (counter > 0)
		{

			if (p[index].tmp_burst_ > 0)
			{
				flagProcess(p, num_process, now);
			}
			else if (p[index].tmp_burst_ == 0)
			{
				p[index].completed = true;
				int min = findMinBurstTime(p, num_process);
				index = indexOfProcessMinBurst(p, num_process, min);
				p[index].response_time = now - p[index].arrive_time;
				p[index].waiting_time = now - p[index].arrive_time;
				p[index].return_time = now + p[index].burst;
				p[index].turnaround_time = p[index].return_time - p[index].arrive_time;
				counter += 1;
				continue;
			}
			p[index].tmp_burst_ -= 1;
		}
		now += 1;
	}
	// -----------------------------------
}

void Priority_Scheduling(Process *p, int num_process)
{
	// To do -----------------------------
	int now = 0, counter = 0;
outer:
	while (counter < num_process)
	{
		flagProcess(p, num_process, now);
		int maxPri = getMaxPriorityInExecutingProcess(p, num_process);
		for (int i = 0; i < num_process; i++)
		{

			if (p[i].executing == true && p[i].completed == false && p[i].priority == maxPri)
			{
				if (p[i].tmp_burst_ == p[i].burst)
				{
					p[i].response_time = now - p[i].arrive_time;
				}
				if (p[i].tmp_burst_ == 0)
				{
					p[i].completed = true;
					p[i].executing = false;
					p[i].return_time = now;
					p[i].turnaround_time = now - p[i].arrive_time;
					counter += 1;
					goto outer;
				}
				p[i].tmp_burst_ -= 1;
				for (int j = 0; j < num_process; j++)
				{
					if (j != i && p[j].executing == true && p[j].completed == false)
					{
						p[j].waiting_time += 1;
					}
				}
				break;
			}
		}
		now += 1;
	}
	// -----------------------------------
}

void RR(Process *p, int num_process, Quantum q)
{
	// To do -----------------------------

	// -----------------------------------
}
