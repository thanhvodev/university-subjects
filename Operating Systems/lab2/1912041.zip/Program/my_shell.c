#include <stdio.h>
#include <sys/types.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <dirent.h>
#include "parse_command.h"
#define MY_PROMPT "My Shell>$ "

void _ls(const char *dir)
{
    //Here we will list the directory
    struct dirent *d;
    DIR *dh = opendir(dir);
    //While the next entry is not readable we will print directory files
    while ((d = readdir(dh)) != NULL)
    {
        //If hidden files are found we continue
        if (d->d_name[0] == '.')
            continue;
        printf("%s  ", d->d_name);
    }
    printf("\n");
}

void _cat(char filename[])
{
    FILE *fptr;
    char c;
    fptr = fopen(filename, "r");
    if (fptr == NULL)
    {
        printf("Cannot open file \n");
        exit(0);
    } // Read contents from file
    c = fgetc(fptr);
    while (c != EOF)
    {
        printf("%c", c);
        c = fgetc(fptr);
    }

    fclose(fptr);
}

int main(void)
{
    char line[MAX_INPUT_SIZE];
    char **tokens;
    int i;
    int count = 0;

    while (1)
    {
        printf(MY_PROMPT);
        bzero(line, MAX_INPUT_SIZE);
        if (fgets(line, sizeof(line), stdin) == NULL)
        {
            printf("\n");
            break;
        }
        char whoami[7] = {'w', 'h', 'o', 'a', 'm', 'i', '\0'};
        tokens = parse_command(line);
        if (strcmp(tokens[0], whoami) == 0)
        {
            printf("My Id is 1912041\n");
        }
        char counter[8] = {'c', 'o', 'u', 'n', 't', 'e', 'r', '\0'};
        if (strcmp(tokens[0], counter) == 0)
        {
            count++;
            printf("Counter has been called %d times\n", count);
        }
        char quit[5] = {'q', 'u', 'i', 't', '\0'};
        if (strcmp(tokens[0], quit) == 0)
        {
            break;
        }
        char echo[] = {'e', 'c', 'h', 'o', '\0'};
        if (strcmp(tokens[0], echo) == 0)
        {
            for (int a = 1; tokens[a] != NULL; a++)
            {
                for (int b = 0; tokens[a][b] != '\0'; b++)
                    printf("%c", tokens[a][b]);
                if (tokens[a + 1] != NULL)
                    printf(" ");
            }
            printf("\n");
        }
        char sleep1[] = {'s', 'l', 'e', 'e', 'p', '\0'};
        if (strcmp(tokens[0], sleep1) == 0)
        {
            int number = atoi(tokens[1]);
            sleep(number);
        }
        char ls1[] = {'l', 's', '\0'};
        if (strcmp(tokens[0], ls1) == 0)
        {
            char cwd[100];
            getcwd(cwd, sizeof(cwd));
            _ls(cwd);
        }
        char cat1[] = {'c', 'a', 't', '\0'};
        if (strcmp(tokens[0], cat1) == 0)
        {
            _cat(tokens[1]);
            printf("\n");
        }
        // !! Comment two below lines after you successfully write Makefile
        // !! Comment two below lines after you successfully write Makefile
        // for(i = 0; tokens[i] != NULL; i++)
        //    printf("found token: %s\n", tokens[i]);

        /* Free the allocated memory */
        for (i = 0; tokens[i] != NULL; i++)
            free(tokens[i]);

        free(tokens);
    }

    return 0;
}
